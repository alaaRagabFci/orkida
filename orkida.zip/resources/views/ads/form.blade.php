<input type="hidden" name="_token" value="{{ csrf_token() }}">

<div class="form-group">
    <label for="exampleInputPassword1">الأعلان الأول</label>
    <textarea rows="2" cols="30" name="ads1" class="form-control" required></textarea>
</div>

<div class="form-group">
    <label for="exampleInputPassword1">الأعلان الثاني</label>
    <textarea rows="2" cols="30" name="ads2" class="form-control" required></textarea>
</div>

<div class="form-group">
    <label for="exampleInputPassword1">الأعلان الثالث</label>
    <textarea rows="2" cols="30" name="ads3" class="form-control" required></textarea>
</div>