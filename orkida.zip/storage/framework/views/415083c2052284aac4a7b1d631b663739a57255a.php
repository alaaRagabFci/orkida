<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

<div class="form-group">
    <label for="exampleInputFile">الخدمة</label>
    <select required  class="form-control" name="service_id">
        <option selected value="">أختر الخدمه </option>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo $service->id; ?>"><?php echo $service->name_ar; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <div class="fileupload fileupload-new" data-provides="fileupload">
    <span class="btn btn-primary btn-file"><span class="fileupload-new">صورة الخدمة</span>
    <span class="fileupload-exists">تغير</span>
    <input type="file" name="image" /></span>
        <span class="fileupload-preview"></span>
        <a href="#"  class="close fileupload-exists" data-dismiss="fileupload" style="float: none">×</a>
        <span class="help-block with-errors errorName"></span>
    </div>
</div>

<div class="form-group" style="display:none;">
    <label for="exampleInputFile">pic path</label>
    <input type="text" name="image" id="image">
</div>

<div class="form-group">
    <label for="exampleInputPassword1">العنوان</label>
    <input type="text" name="name_ar" required class="form-control">
    <span class="help-block with-errors errorName"></span>
</div>

<div class="form-group">
    <label for="exampleInputPassword1">Title</label>
    <input type="text" name="name_en" required class="form-control">
    <span class="help-block with-errors errorName"></span>
</div>

<div class="form-group">
    <label for="exampleInputPassword1">image title</label>
    <input type="text" name="image_title" required class="form-control">
    <span class="help-block with-errors errorName"></span>
</div>

<div class="form-group">
    <label for="exampleInputPassword1">Image alt</label>
    <textarea rows="2" cols="30" name="image_alt" class="form-control" required></textarea>
</div>

<div class="form-group">
    <label for="exampleInputPassword1">تفعيل</label>
    <input data-onstyle="danger" type="checkbox" name="is_active" id="isActive"  data-toggle="toggle">
</div>



<?php /**PATH C:\xampp\htdocs\orkida\resources\views/services_types/form_update.blade.php ENDPATH**/ ?>