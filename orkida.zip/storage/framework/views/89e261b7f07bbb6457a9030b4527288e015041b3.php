<li class="nav-item <?php echo e(Request::is('/adminpanel') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/')); ?>" class="nav-link nav-toggle">
        <i class="icon-home"></i>
        <span class="title">لوحة التحكم</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/settings') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/settings')); ?>" class="nav-link nav-toggle">
        <i class="fa fa-cogs"></i>
        <span class="title">الأعدادات</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/site_phones') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/site_phones')); ?>" class="nav-link nav-toggle">
        <i class="fas fa-address-book"></i>
        <span class="title">أرقام هواتف الموقع</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/categories') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/categories')); ?>" class="nav-link nav-toggle">
        <i class="fa fa-list-alt" aria-hidden="true"></i>
        <span class="title">الأقسام الرئيسية</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/users') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/users')); ?>" class="nav-link ">
        <i class="fa fa-users"></i>
        <span class="title"> الأعضاء </span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/services', 'adminpanel/services/*', 'adminpanel/services_types', 'adminpanel/services/create') ? 'start active open':''); ?>">
    <a href="javascript:;" class="nav-link nav-toggle">
        <i class="fa fa-server"></i>
        <span class="title">الخدمات</span>
        <span class="selected"></span>
        <span class="arrow open"></span>
    </a>
    <ul class="sub-menu">
        <li class="nav-item <?php echo e(Request::is('adminpanel/services/create') ? 'start active open':''); ?>">
            <a href="<?php echo e(url('adminpanel/services/create')); ?>" class="nav-link nav-toggle">
                <i class="fas fa-angle-left"></i>
                <span class="title">أضافة خدمه</span>
                <span class="selected"></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('adminpanel/services') ? 'start active open':''); ?>">
            <a href="<?php echo e(url('adminpanel/services')); ?>" class="nav-link nav-toggle">
                <i class="fas fa-angle-left"></i>
                <span class="title">الخدمات</span>
                <span class="selected"></span>
            </a>
        </li>
        
            
                
                
                
            
        
    </ul>
</li>

<li class="nav-item  <?php echo e(Request::is('adminpanel/blogs', 'adminpanel/blogs/*', 'adminpanel/blogs/create') ? 'start active open':''); ?>">
    <a href="javascript:;" class="nav-link nav-toggle">
        <span class="icon">
            <i class="fas fa-blog"></i>
        </span>
        <span class="title">المقالات</span>
        <span class="selected"></span>
        <span class="arrow open"></span>
    </a>
    <ul class="sub-menu">
        <li class="nav-item <?php echo e(Request::is('adminpanel/blogs/create') ? 'start active open':''); ?>">
            <a href="<?php echo e(url('adminpanel/blogs/create')); ?>" class="nav-link nav-toggle">
                <i class="fas fa-angle-left"></i>
                <span class="title">أضافة مقال</span>
                <span class="selected"></span>
            </a>
        </li>
        <li class="nav-item <?php echo e(Request::is('adminpanel/blogs') ? 'start active open':''); ?>">
            <a href="<?php echo e(url('adminpanel/blogs')); ?>" class="nav-link nav-toggle">
                <i class="fas fa-angle-left"></i>
                <span class="title">المقالات</span>
                <span class="selected"></span>
            </a>
        </li>
    </ul>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/pest_libraries') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/pest_libraries')); ?>" class="nav-link nav-toggle">
        <span class="icon">
        <i class="fas fa-pastafarianism"></i>
        </span>
        <span class="title">مكتبة الأفات</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/article_types') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/article_types')); ?>" class="nav-link nav-toggle">
       <span class="icon">
            <i class="fas fa-blog"></i>
        </span>
        <span class="title">أقسام المدونة</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/ads') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/ads')); ?>" class="nav-link nav-toggle">
        <span class="icon">
        <i class="fas fa-audio-description"></i>
        </span>
        <span class="title">الأعلانات</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/about_us') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/about_us')); ?>" class="nav-link nav-toggle">
        <i class="fas fa-address-card"></i>
        <span class="title">من نحن</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/company_valuables') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/company_valuables')); ?>" class="nav-link nav-toggle">
        <i class="fa fa-server"></i>
        <span class="title">فيم الشركه</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/faqs') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/faqs')); ?>" class="nav-link nav-toggle">
         <span class="icon">
        <i class="fas fa-question"></i>
         </span>
        <span class="title">الأسئله الشائعه</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/orders') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/orders')); ?>" class="nav-link nav-toggle">
        <i class="fab fa-first-order"></i>
        <span class="title">الطلبات</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/messages') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/messages')); ?>" class="nav-link nav-toggle">
        <i class="fab fa-facebook-messenger"></i>
        <span class="title">الرسايل</span>
        <span class="selected"></span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminpanel/sliders') ? 'start active open':''); ?>">
    <a href="<?php echo e(url('adminpanel/sliders')); ?>" class="nav-link nav-toggle">
        <i class="fab fa-adversal"></i>
        <span class="title">سلايدر العروض</span>
        <span class="selected"></span>
    </a>
</li>


<?php /**PATH C:\xampp\htdocs\orkida\resources\views/admin_layouts/menu.blade.php ENDPATH**/ ?>