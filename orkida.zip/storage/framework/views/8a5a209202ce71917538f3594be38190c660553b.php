<div class="actions" >
	<a href="<?php echo e(url('/adminpanel/services/'.$id.'/edit')); ?>">
		<button type="button" class="Btn btn btn-default btn-xs" data-id="<?php echo e($id); ?>"><i class="fa fa-pencil"></i></button>
	</a>
	<form action="<?php echo e(url( strtolower($controller), $id)); ?>" class="deleteForm" method="POST" style="display: inline;">
		<input type="hidden" name="_method" value="DELETE">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-times"></i></button>
	</form>
</div>
<?php /**PATH C:\xampp\htdocs\orkida\resources\views/services/actionBtns.blade.php ENDPATH**/ ?>