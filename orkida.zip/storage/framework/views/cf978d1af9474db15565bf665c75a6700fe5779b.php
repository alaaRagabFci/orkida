<?php $__env->startSection('title','أقسام الأسئله'); ?>
<?php $__env->startSection('breadcrumb','أقسام الأسئله'); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<div class="row">
  <div class="col-md-12">
    <!-- BEGIN EXAMPLE TABLE PORTLET-->
    <div class="portlet light bordered">
      <div class="portlet-title">
        <div class="caption font-dark">
          <i class="icon-settings font-dark"></i>
          <span class="caption-subject bold uppercase">بيانات أقسام الأسئله</span>
        </div>
        <div class="tools"> </div>
      </div>
      <div class="portlet-body">
        <div class="table-toolbar">
          <div class="row">
            <div class="col-md-6">
              <div class="btn-group">
                <button  data-toggle="modal" data-target="#addModal" id="sample_editable_1_new" class="btn btn-primary">
                  أضافة قسم
                  <i class="fa fa-plus"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
              <table class="table table-striped table-bordered table-hover" id="phones">
                <thead>
                  <th class="col-md-1">القسم</th>
                  <th class="col-md-1">Category</th>
                  <th class="col-md-1">خيارات</th>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $tableData->getData()->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($row->category_ar); ?></td>
                    <td><?php echo e($row->category_en); ?></td>
                    <td><?php echo $row->actions; ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <!-- END EXAMPLE TABLE PORTLET-->
        </div>
      </div>

      <?php echo $__env->make('admin_layouts.Add_Modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('admin_layouts.Edit_Modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php $__env->stopSection(); ?>

      <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('/admin_ui/assets/layouts/layout4/scripts/insert.js')); ?>" type="text/javascript"></script>
      <script type="text/javascript">
       $(document).ready(function() {
        oTable = $('#phones').DataTable({
          "processing": true,
          "serverSide": true,
          "responsive": true,
          'paging'      : true,
          "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Arabic.json"
          },
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : false,
          "ajax": <?php echo e($tableData->getData()->recordsFiltered); ?>,
          "columns": [
          {data: 'category_ar', name: 'category_ar'},
          {data: 'category_en', name: 'category_en'},
          {data: 'actions', name: 'actions', orderable: false, searchable: false}
          ]
        })
      });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.inc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orkida\resources\views/question_categories/index.blade.php ENDPATH**/ ?>