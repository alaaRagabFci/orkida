
<div class="modal fade" data-backdrop="static" data-keyboard="false" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="addModalLabel"><i class="fa fa-plus-circle"></i> أضافة <?php echo e($modal_); ?></h4>
            </div>
            <form role="form" method="POST" class="addForm" action="<?php echo e(url('adminpanel/'.$modal.'/store')); ?>" data-toggle="validator"  enctype="multipart/form-data">
                <div class="modal-body">
                    <?php echo $__env->make($modal.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submitForm" class="btn btn-primary">موافق</button>
                    <button type="button" class="btn btn-danger closeModal">غلق</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\orkida\resources\views/admin_layouts/Add_imgModal.blade.php ENDPATH**/ ?>