<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

<input type="hidden" name="relationId" value="<?php echo e($relationId); ?>">
<input type="hidden" name="type" value="<?php echo e($type); ?>">
<div class="form-group">
    <label for="exampleInputPassword1">Meta tags</label>
    <input type="text" name="tags" class="form-control input-large" required  data-role="tagsinput">
    <span class="help-block with-errors errorName"></span>
</div>
<?php /**PATH C:\xampp\htdocs\orkida\resources\views/meta_tags/form.blade.php ENDPATH**/ ?>