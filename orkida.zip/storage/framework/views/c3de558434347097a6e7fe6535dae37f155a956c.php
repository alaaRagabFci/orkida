<?php $__env->startSection('title','لوحة التحكم'); ?>
<?php $__env->startSection('header','لوحة التحكم'); ?>
<?php $__env->startSection('head_description','الأحصائيات, الأشكال البيانيه والتقرير'); ?>
<?php $__env->startSection('breadcrumb','لوحة التحكم'); ?>
<?php $__env->startSection('content'); ?>
                    <!-- BEGIN PAGE BASE CONTENT -->
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                              <a href="<?php echo e(url('messages')); ?>">
                            <div class="dashboard-stat2 bordered">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-green-sharp">
                                        <span data-counter="counterup" data-value="<?php echo e($messages); ?>"></span>
                                        </h3>
                                        <small>الرسايل</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fab fa-facebook-messenger"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e($messages); ?>%;" class="progress-bar progress-bar-success green-sharp">
                                            <span class="sr-only"><?php echo e($messages); ?>%</span>
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-number"> <?php echo e($messages); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                             <a href="<?php echo e(url('blogs')); ?>">
                            <div class="dashboard-stat2 bordered">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-red-haze">
                                        <span data-counter="counterup" data-value="<?php echo e($blogs); ?>"></span>
                                        </h3>
                                        <small>المدونات</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-blog"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e($blogs); ?>%;" class="progress-bar progress-bar-success green-sharp">
                                            <span class="sr-only"><?php echo e($blogs); ?>%</span>
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-number"> <?php echo e($blogs); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                             <a href="<?php echo e(url('services')); ?>">
                            <div class="dashboard-stat2 bordered">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-blue-sharp">
                                          <span data-counter="counterup" data-value="<?php echo e($services); ?>"></span>
                                        </h3>
                                        <small>الخدمات</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-server"></i>
                                    </div>
                                </div>
                                 <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e($services); ?>%;" class="progress-bar progress-bar-success green-sharp">
                                            <span class="sr-only"><?php echo e($services); ?>%</span>
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-number"> <?php echo e($services); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                             <a href="<?php echo e(url('orders')); ?>">
                            <div class="dashboard-stat2 bordered">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-purple-soft">
                                            <span data-counter="counterup" data-value="<?php echo e($orders); ?>"></span>
                                        </h3>
                                        <small>الطلبات</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fab fa-first-order"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e($orders); ?>%;" class="progress-bar progress-bar-success green-sharp">
                                            <span class="sr-only"><?php echo e($orders); ?>%</span>
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-number"> <?php echo e($orders); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        </div>

                    <!-- END PAGE BASE CONTENT -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.inc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orkida\resources\views/dashboard.blade.php ENDPATH**/ ?>