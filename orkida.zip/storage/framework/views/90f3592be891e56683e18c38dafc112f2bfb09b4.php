<?php $__env->startSection('title','الرسايل'); ?>
<?php $__env->startSection('breadcrumb','الرسايل'); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<div class="row">
  <div class="col-md-12">
    <!-- BEGIN EXAMPLE TABLE PORTLET-->
    <div class="portlet light bordered">
      <div class="portlet-title">
        <div class="caption font-dark">
          <i class="icon-settings font-dark"></i>
          <span class="caption-subject bold uppercase">الرسايل</span>
        </div>
        <div class="tools"> </div>
      </div>
      <div class="portlet-body">
              <table class="table table-striped table-bordered table-hover" id="messages">
                <thead>
                  <th class="col-md-1">الرساله</th>
                  <th class="col-md-1">نعم أم لا</th>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $tableData->getData()->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($row->message); ?></td>
                    <td><?php echo e($row->is_benefit); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <!-- END EXAMPLE TABLE PORTLET-->
        </div>
      </div>

        <?php $__env->stopSection(); ?>

      <?php $__env->startSection('scripts'); ?>
      <script type="text/javascript">
       $(document).ready(function() {
        oTable = $('#messages').DataTable({
          "processing": true,
          "serverSide": true,
          "responsive": true,
          'paging'      : true,
          "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Arabic.json"
          },
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : false,
          "ajax": <?php echo e($tableData->getData()->recordsFiltered); ?>,
          "columns": [
          {data: 'message', name: 'message'},
          {data: 'is_benefit', name: 'is_benefit'}
          ]
        })
      });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.inc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\orkida\resources\views/messages/index.blade.php ENDPATH**/ ?>