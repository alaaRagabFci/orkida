<div class="actions" >
	<button type="button" class="edit Btn btn btn-default btn-xs" data-id="<?php echo e($id); ?>"><i class="fa fa-pencil"></i> تعديل</button>
</div>
<?php /**PATH C:\xampp\htdocs\orkida\resources\views/settings/actionBtns.blade.php ENDPATH**/ ?>