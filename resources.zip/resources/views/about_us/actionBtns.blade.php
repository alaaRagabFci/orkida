<div class="actions" >
	<button type="button" class="edit Btn btn btn-default btn-xs" data-id="{{$id}}"><i class="fa fa-pencil"></i> تعديل</button>
</div>
